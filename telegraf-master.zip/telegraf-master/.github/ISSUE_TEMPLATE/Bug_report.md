---
name: Bug report
about: Create a report to help us improve

---

### Relevant telegraf.conf:

### System info:

[Include Telegraf version, operating system name, and other relevant details]

### Steps to reproduce:

1. ...
2. ...

### Expected behavior:

### Actual behavior:

### Additional info:

[Include gist of relevant config, logs, etc.]
