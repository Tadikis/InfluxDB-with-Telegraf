---
name: Feature request
about: Suggest an idea for this project

---

## Feature Request

Opening a feature request kicks off a discussion.

### Proposal:

### Current behavior:

### Desired behavior:

### Use case: [Why is this important (helps with prioritizing requests)]
