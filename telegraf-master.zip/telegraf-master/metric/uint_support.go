// +build uint64

package metric

func init() {
	EnableUintSupport()
}
