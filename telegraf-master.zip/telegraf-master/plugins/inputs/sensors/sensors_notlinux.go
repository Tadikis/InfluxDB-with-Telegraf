// +build !linux

package sensors
