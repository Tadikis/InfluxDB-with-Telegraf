// +build !linux

package kernel_vmstat
