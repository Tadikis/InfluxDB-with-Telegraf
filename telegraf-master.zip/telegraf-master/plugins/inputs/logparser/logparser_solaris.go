// +build solaris

package logparser
