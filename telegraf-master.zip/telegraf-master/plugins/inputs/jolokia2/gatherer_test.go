package jolokia2

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestJolokia2_makeReadRequests(t *testing.T) {
	cases := []struct {
		metric   Metric
		expected []ReadRequest
	}{
		{
			metric: Metric{
				Name:  "object",
				Mbean: "test:foo=bar",
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{},
				},
			},
		}, {
			metric: Metric{
				Name:  "object_with_an_attribute",
				Mbean: "test:foo=bar",
				Paths: []string{"biz"},
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"biz"},
				},
			},
		}, {
			metric: Metric{
				Name:  "object_with_attributes",
				Mbean: "test:foo=bar",
				Paths: []string{"baz", "biz"},
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"baz", "biz"},
				},
			},
		}, {
			metric: Metric{
				Name:  "object_with_an_attribute_and_path",
				Mbean: "test:foo=bar",
				Paths: []string{"biz/baz"},
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"biz"},
					Path:       "baz",
				},
			},
		}, {
			metric: Metric{
				Name:  "object_with_an_attribute_and_a_deep_path",
				Mbean: "test:foo=bar",
				Paths: []string{"biz/baz/fiz/faz"},
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"biz"},
					Path:       "baz/fiz/faz",
				},
			},
		}, {
			metric: Metric{
				Name:  "object_with_attributes_and_paths",
				Mbean: "test:foo=bar",
				Paths: []string{"baz/biz", "faz/fiz"},
			},
			expected: []ReadRequest{
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"baz"},
					Path:       "biz",
				},
				ReadRequest{
					Mbean:      "test:foo=bar",
					Attributes: []string{"faz"},
					Path:       "fiz",
				},
			},
		},
	}

	for _, c := range cases {
		payload := makeReadRequests([]Metric{c.metric})

		assert.Equal(t, len(c.expected), len(payload), "Failing case: "+c.metric.Name)
		for _, actual := range payload {
			assert.Contains(t, c.expected, actual, "Failing case: "+c.metric.Name)
		}
	}
}
