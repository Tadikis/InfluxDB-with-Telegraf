// +build freebsd

package nats
